#if UNITY_EDITOR
using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using MoreMountains.Feedbacks;
using System;
using UnityEditor;

[RequireComponent(typeof(MMF_Player))]
public class MageFeelHelper : MonoBehaviour
{
    #region MMF setting

    [Serializable]
    public class MMFScaleSetting
    {
        public float RemapCurveZero = 1f;
        public float RemapCurveOne = 1.1f;
        public bool UseScalePercent = true;
        [Range(1f, 100f)]
        public float ScalePercent = 10;
        public float AnimateScaleDuration = 0.17f;
        public bool AnimateX = false;
        public bool AnimateY = true;
        public bool AnimateZ = false;
    }

    [Serializable]
    public class MMFFlickerSetting
    {
        public float FlickerOctave = 0.1f;
        public float FlickerDuration = 0.17f;
        public bool UseBlockProperties = true;
        public string SpriteRendererTextureProperty = "_Tint";
        public MMF_Flicker.Modes Mode = MMF_Flicker.Modes.PropertyName;
    }

    #endregion

    public MMFScaleSetting ScaleSetting;
    public MMFFlickerSetting FlickerSetting;

    [ContextMenu(nameof(AddFeedbackScale))]

    public void AddFeedbackScale()
    {
        MMF_Player player = gameObject.GetComponent<MMF_Player>();
        MMF_Scale scale = new()
        {
            AnimateScaleTarget = transform,
            AnimateScaleDuration = ScaleSetting.AnimateScaleDuration,
            RemapCurveZero = ScaleSetting.RemapCurveZero,
            RemapCurveOne = ScaleSetting.RemapCurveOne,
            AnimateX = ScaleSetting.AnimateX,
            AnimateY = ScaleSetting.AnimateY,
            AnimateZ = ScaleSetting.AnimateZ,
            Label = "Scale " + gameObject.name
        };

        if (ScaleSetting.UseScalePercent)
        {
            scale.RemapCurveZero = transform.localScale.y;
            scale.RemapCurveOne = scale.RemapCurveZero + scale.RemapCurveZero / 100 * ScaleSetting.ScalePercent;
        }

        player.AddFeedback(scale);
    }

    [ContextMenu(nameof(AddFeedbackFlicker))]
    public void AddFeedbackFlicker()
    {
        MeshRenderer[] meshRenderers = gameObject.GetComponentsInChildren<MeshRenderer>(true);
        MMF_Player player = gameObject.GetComponent<MMF_Player>();

        for (int i = 0; i < meshRenderers.Length; i++)
        {
            MMF_Flicker flicker = new()
            {
                BoundRenderer = meshRenderers[i],
                FlickerDuration = FlickerSetting.FlickerDuration,
                FlickerOctave = FlickerSetting.FlickerOctave,
                Label = "Flicker " + meshRenderers[i].name,
                Mode = FlickerSetting.Mode,
                UseMaterialPropertyBlocks = FlickerSetting.UseBlockProperties,
                SpriteRendererTextureProperty = FlickerSetting.SpriteRendererTextureProperty
            };
            player.AddFeedback(flicker);
        }

        SkinnedMeshRenderer[] skinnedMeshRenderers = gameObject.GetComponentsInChildren<SkinnedMeshRenderer>(true);

        for (int i = 0; i < skinnedMeshRenderers.Length; i++)
        {
            MMF_Flicker flicker = new()
            {
                BoundRenderer = skinnedMeshRenderers[i],
                FlickerDuration = FlickerSetting.FlickerDuration,
                FlickerOctave = FlickerSetting.FlickerOctave,
                Label = "Flicker " + skinnedMeshRenderers[i].name,
                Mode = FlickerSetting.Mode,
                UseMaterialPropertyBlocks = FlickerSetting.UseBlockProperties,
                SpriteRendererTextureProperty = FlickerSetting.SpriteRendererTextureProperty
            };
            player.AddFeedback(flicker);
        }

    }


    [ContextMenu(nameof(AddFeedbackTemplate))]
    public void AddFeedbackTemplate()
    {
        MMF_Player player = gameObject.GetComponent<MMF_Player>();

        if (player.FeedbacksList != null)
        {
            player.FeedbacksList.Clear();
        }

        AddFeedbackScale();
        AddFeedbackFlicker();

        EditorUtility.SetDirty(gameObject);
    }
}

#endif
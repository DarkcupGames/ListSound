using UnityEngine;
using UnityEngine.UI;
using static MCP.Unity.UnityUtils;
using System.Collections;
using System.Collections.Generic;
using MCP.DataModels.BaseModels;
using Image = UnityEngine.UI.Image;
using MCP.Manager;
using TZU;

public static class UiExtensions
{
    //Assets/Resources/Chest/WoodenChest_1.png
    private static string relativeChestPath = "Chest/";
    private static string relativeGemPath = "GameIcon/Gem/";
    private static string relativeArenaPath = "GameIcon/Arena/";
    private static string DungeonAnimatorPath = "AnimatorBoss/";
    static Material GreyMaterial;
    static Material GreyScrollMaterial;
    static Material ChestNone;
    static Material ChestOpening;
    static Material ChestReady;

    public static void SetAvatarCard(Image avatar, string url)
    {
        if (avatar == null) return;
        if (!string.IsNullOrEmpty(url))
        {
            string key = url;
            key = key.Replace(" ", "");
            key = key.Replace(".", "");

            AssetManager.instance.Load<Sprite>(key, result => SetSpriteForImage(avatar, result));
        }
    }
    public static void SetBackgroundCard(Image background, string url)
    {
        if (background == null) return;
        if (!string.IsNullOrEmpty(url))
        {
            string key = "CardBG_" + url;
            key = key.Replace(" ", "");
            key = key.Replace(".", "");

            AssetManager.instance.Load<Sprite>(key, result =>
            {
                SetSpriteForImage(background, result);
            });
        }
    }
    public static void SetFrameCard(Image frame, string url)
    {
        if (frame == null) return;
        if (!string.IsNullOrEmpty(url))
        {
            //string key = "CardFrame_" + url;
            string key = "CardFrame_" + (url != "Legendary" ? "All" : url);
            key = key.Replace(" ", "");
            key = key.Replace(".", "");

            AssetManager.instance.Load<Sprite>(key, result => SetSpriteForImage(frame, result));
        }
    }
    public static void SetFillCard(Image frame, bool canUpgrade)
    {
        if (frame == null) return;
        string key = "CardFill_" + canUpgrade;
        AssetManager.instance.Load<Sprite>(key, result => SetSpriteForImage(frame, result));
    }
    public static void SetLevelCard(Image level, string url)
    {
        if (level == null) return;
        if (!string.IsNullOrEmpty(url))
        {
            string key = "CardLevel_" + url;
            key = key.Replace(" ", "");
            key = key.Replace(".", "");

            AssetManager.instance.Load<Sprite>(key, result => SetSpriteForImage(level, result));
        }

    }
    public static void SetCardType(Image cardType, string url)
    {
        if (cardType == null) return;
        if (!string.IsNullOrEmpty(url))
        {
            string key = "CardFill_" + url;
            key = key.Replace(" ", "");
            key = key.Replace(".", "");

            AssetManager.instance.Load<Sprite>(key, result => SetSpriteForImage(cardType, result));
        }

    }
    public static void SetIconUpgradeCard(Image icon, bool canUpgrade)
    {
        if (icon == null) return;
        string key = "CardCanUpgrade_" + canUpgrade;
        AssetManager.instance.Load<Sprite>(key, result => SetSpriteForImage(icon, result));

    }
    public static void SetLevelCardText(TMPro.TMP_Text tMP_Text, string url, TMPro.TMP_FontAsset[] fontAssets = null)
    {
        if (tMP_Text == null) return;
        if (url == "Legendary")
        {
            tMP_Text.color = new Color32(255, 186, 47, 255);
            if (fontAssets != null && fontAssets.Length > 0)
                tMP_Text.font = fontAssets[1];
        }
        else if (url == "Epic")
        {
            tMP_Text.color = new Color32(228, 136, 252, 255);
            if (fontAssets != null && fontAssets.Length > 0)
                tMP_Text.font = fontAssets[0];
        }
        else if (url == "Rare")
        {
            tMP_Text.color = new Color32(40, 190, 251, 255);
            if (fontAssets != null && fontAssets.Length > 0)
                tMP_Text.font = fontAssets[0];
        }
        else if (url == "Common")
        {
            tMP_Text.color = new Color32(126, 233, 36, 255);
            if (fontAssets != null && fontAssets.Length > 0)
                tMP_Text.font = fontAssets[0];
        }

    }
    public static void SetIconItem(Image avatar, string url)
    {
        if (avatar == null) return;
        if (!string.IsNullOrEmpty(url))
        {
            string key = url;
            key = key.Replace(" ", "");
            key = key.Replace(".", "");
            AssetManager.instance.Load<Sprite>(key, result => SetSpriteForImage(avatar, result));
        }

    }
    public static void SetIconGem(Image avatar, string url, int level)
    {
        if (avatar == null) return;
        if (!string.IsNullOrEmpty(url))
        {
            string key = url + "_" + level;
            key = key.Replace(" ", "");
            key = key.Replace(".", "");
            Sprite[] sprite1s = Resources.LoadAll<Sprite>(relativeGemPath + key);
            if (sprite1s != null && sprite1s.Length > 0)
            {
                SetSpriteForImage(avatar, sprite1s[0]);
            }

        }

    }
    public static void SetIconChest(Image avatar, string url)
    {
        if (avatar == null) return;
        string key = url;
        if (!string.IsNullOrEmpty(key))
        {
            url = url.Replace(" ", "");
            url = url.Replace(".", "");
            Sprite[] sprite1s = Resources.LoadAll<Sprite>(relativeChestPath + url);
            if (sprite1s != null && sprite1s.Length > 0)
            {
                SetSpriteForImage(avatar, sprite1s[0]);
            }

        }
    }
    public static void SetIconStat(Image avatar, string url)
    {
        if (avatar == null) return;
        if (!string.IsNullOrEmpty(url))
        {
            string key = url;
            key = key.Replace(" ", "");
            key = key.Replace(".", "");
            AssetManager.instance.Load<Sprite>(key, result => SetSpriteForImage(avatar, result));
        }
    }
    public static void SetIconEmoticon(Transform anchor, string url, System.Action complete =null)
    {
        if (anchor == null) return;
        if (!string.IsNullOrEmpty(url))
        {
            string key =  url;
            key = key.Replace(" ", "");
            key = key.Replace(".", "");
            AssetManager.instance.Load<GameObject>(key, result =>
            {
               GameObject boss = UnityEngine.Object.Instantiate(result);
                boss.transform.SetParent(anchor);
                boss.transform.localPosition = Vector3.zero;
                boss.transform.localScale = Vector3.one;
                //boss.transform.localRotation = Quaternion.identity;
                complete?.Invoke();
            });
        }
    }
    public static void SetBossIcon(Transform anchor, string url, System.Action complete = null)
    {
        if (anchor == null) return;
        if (!string.IsNullOrEmpty(url))
        {
            string key = url;
            key = key.Replace(" ", "");
            key = key.Replace(".", "");
            AssetManager.instance.Load<GameObject>(key, result =>
            {
                for (var i = anchor.transform.childCount - 1; i >= 0; i--)
                {
                    Object.Destroy(anchor.GetChild(i).gameObject);
                }
                GameObject boss = UnityEngine.Object.Instantiate(result);
                boss.transform.SetParent(anchor);
                boss.transform.localPosition = Vector3.zero;
                boss.transform.localScale = Vector3.one;
                boss.transform.localRotation = Quaternion.identity;
            });
        }
    }
    public static void SetArenaIcon(Transform anchor, string url, System.Action complete = null)
    {
        if (anchor == null) return;
        if (!string.IsNullOrEmpty(url))
        {
            string key = url;
            key = key.Replace(" ", "");
            key = key.Replace(".", "");
            AssetManager.instance.Load<GameObject>(key, result =>
            {
                for (var i = anchor.transform.childCount - 1; i >= 0; i--)
                {
                    Object.Destroy(anchor.GetChild(i).gameObject);
                }
                GameObject boss = UnityEngine.Object.Instantiate(result);
                boss.transform.SetParent(anchor);
                boss.transform.localPosition = Vector3.zero;
                boss.transform.localScale = Vector3.one;
                boss.transform.rotation = Quaternion.identity;
                complete?.Invoke();
            });
        }
    }
    public static void SetIconCurrencyPack(Image avatar, int currencyId, string numberCurrency)
    {
        if (avatar == null) return;
        if (currencyId == 1)
            SetIconDiamond(avatar, numberCurrency);
        else if (currencyId == 2) SetIconGold(avatar, numberCurrency);
    }
    public static int GetNameCurrencyPack(int currencyId, int numberCurrency)
    {
        if (currencyId == 1)
            return GetDiamondPackName(numberCurrency);
        else if (currencyId == 2) return GetGoldPackName(numberCurrency);
        return 0;
    }
    public static void SetIconCurrency(Image avatar, string url)
    {
        if (avatar == null) return;
        if (!string.IsNullOrEmpty(url))
        {
            string key = url;
            key = key.Replace(" ", "");
            key = key.Replace(".", "");
            AssetManager.instance.Load<Sprite>(key, result => SetSpriteForImage(avatar, result));
        }
    }
    private static int GetDiamondPackName(int numberCurrency)
    {
        int key = 0;
        //if (numberCurrency <= 20) key = 323;
        if (numberCurrency <= 80) key = 322;
        else if (numberCurrency <= 500) key = 324;
        else if (numberCurrency <= 1200) key = 321;
        else if (numberCurrency <= 2500) key = 320;
        else if (numberCurrency <= 6500) key = 325;
        else key = 323;
        return key;
    }
    private static int GetGoldPackName(int numberCurrency)
    {
        int key = 0;
        if (numberCurrency <= 1000) key = 327;
        else if (numberCurrency <= 10000) key = 326;
        else key = 328;
        return key;
    }
    private static void SetIconDiamond(Image avatar, string numberCurrency)
    {
        if (avatar == null) return;
        if (int.TryParse(numberCurrency, out int result))
        {
            Dialog dialog = DataHolder.Instance().GetData<Dialog>(GetDiamondPackName(result));
            string key = dialog.GetName(0);
            SetIconBundle(avatar, key);
        }

    }
    private static void SetIconGold(Image avatar, string numberCurrency)
    {
        if (avatar == null) return;
        if (int.TryParse(numberCurrency, out int result))
        {
            Dialog dialog = DataHolder.Instance().GetData<Dialog>(GetGoldPackName(result));
            string key = dialog.GetName(0);
            SetIconBundle(avatar, key);
        }

    }
    public static void SetIconBundle(Image avatar, string url)
    {
        if (avatar == null) return;
        if (!string.IsNullOrEmpty(url))
        {
            string key = url;
            key = key.Replace(" ", "");
            key = key.Replace(".", "");
            AssetManager.instance.Load<Sprite>(key, result => SetSpriteForImage(avatar, result));
        }
    }

    public static void SetRandomIcon(Image avatar, string itemClass, string rareType="")
    {
        string key = "Icon_" + itemClass + rareType;
        key = key.Replace(" ", "");
        key = key.Replace(".", "");
        AssetManager.instance.Load<Sprite>(key, result =>
        {
            SetSpriteForImage(avatar, result);
        });
    }
    public static void SetIconArena(Image avatar, string url)
    {
        if (avatar == null) return;
        string key = url;
        if (!string.IsNullOrEmpty(key))
        {
            url = url.Replace(" ", "");
            url = url.Replace(".", "");
            Sprite[] sprite1s = Resources.LoadAll<Sprite>(relativeArenaPath + url);
            if (sprite1s != null && sprite1s.Length > 0)
            {
                SetSpriteForImage(avatar, sprite1s[0]);
            }

        }
    }
    public static void SetIconCampaign(Image avatar, string url)
    {
        if (avatar == null) return;
        if (!string.IsNullOrEmpty(url))
        {
            string key = url;
            key = key.Replace(" ", "");
            key = key.Replace(".", "");

            AssetManager.instance.Load<Sprite>(key, result => SetSpriteForImage(avatar, result));
        }
    }
    public static void SetColorImage(Image image, Color color)
    {
        if (image)
            image.color = color;
    }
    public static void SetImage(Image image, Sprite sprite)
    {
        if (image)
            image.sprite = sprite;
    }
    public static void SetRuntimeAnimatorController(AnimatorOverrideController animatorOverrideController, string url)
    {
        if (animatorOverrideController == null) return;
        string key = url;
        if (string.IsNullOrEmpty(key) == false)
        {

            url = url.Replace(" ", "");
            url = url.Replace(".", "");
            RuntimeAnimatorController animatorController = Resources.Load<RuntimeAnimatorController>(DungeonAnimatorPath + url);
            if (animatorController != null)
            {
                animatorOverrideController.runtimeAnimatorController = animatorController;

            }
        }
    }
    public static void SetMaterialChestBackground(Image chest, RewardState rewardState)
    {
        if (chest == null) return;
        string url = "";
        switch (rewardState)
        {
            case RewardState.None:
                url = "DB/Materials/Chest_" + rewardState;
                ChestNone ??= Resources.Load<Material>(url);
                chest.material = ChestNone;
                break;
            case RewardState.Opening:
                url = "DB/Materials/Chest_" + rewardState;
                ChestOpening ??= Resources.Load<Material>(url);
                chest.material = ChestOpening;
                break;
            case RewardState.Ready:
                url = "DB/Materials/Chest_" + rewardState;
                ChestReady ??= Resources.Load<Material>(url);
                chest.material = ChestReady;
                break;
        }
    }
    public static void SetMaterialGrey<T>(T[] graphic, bool isScroll) where T : UnityEngine.UI.Graphic
    {
        if (!isScroll)
        {
            //Assets/Resources/DB/Materials/Grey.mat
            if (GreyMaterial == null) GreyMaterial = Resources.Load<Material>("DB/Materials/Grey");
            for (int i = 0; i < graphic.Length; i++)
            {
                if (graphic[i])
                    graphic[i].material = GreyMaterial;
            }
        }
        else
        {
            //Assets/Resources/DB/Materials/GreyScroll.mat
            if (GreyScrollMaterial == null)
                GreyScrollMaterial = Resources.Load<Material>("DB/Materials/GreyScroll");
            for (int i = 0; i < graphic.Length; i++)
            {
                if (graphic[i])
                    graphic[i].material = GreyScrollMaterial;
            }
        }

    }
    public static void SetMateriaDefault<T>(T[] graphic) where T : UnityEngine.UI.Graphic
    {   
        if(graphic == null) return;

        for (int i = 0; i < graphic.Length; i++)
        {
            if (graphic[i])
                graphic[i].material = default;
        }
    }
    public static string GetStringRatity(RareType rareType)
    {
        return rareType switch
        {
            RareType.Common => GameManager.instance.GetDialog(344),
            RareType.Rare => GameManager.instance.GetDialog(345),
            RareType.Epic => GameManager.instance.GetDialog(346),
            RareType.Legendary => GameManager.instance.GetDialog(347),
            _ => ""
        };
    }
}

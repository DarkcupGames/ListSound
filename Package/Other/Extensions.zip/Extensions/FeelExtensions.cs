using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using MoreMountains.Feedbacks;

public static class FeelExtensions
{
    public static MMF_Player GetMMF_Player(GameObject gameObject)
    {
        MMF_Player result = null;

        if (gameObject)
        {
            result = gameObject.GetComponent<MMF_Player>();
        }

        return result;
    }

    public static void SetRenderersColor(Renderer[] renderers, Color color)
    {
        if (renderers == null) return;

        for (int i = 0, count = renderers.Length; i < count; i++)
        {
            SetRendererColor(renderers[i], color);
        }
    }

    public static void SetRenderersColor(List<Renderer> renderers, Color color)
    {
        if (renderers == null) return;
        renderers.ForEach(r => SetRendererColor(r, color));
    }


    public static void SetRendererColor(Renderer renderer, Color color)
    {
        if (renderer == null) return;
        renderer.material.color = color;
    }
}
